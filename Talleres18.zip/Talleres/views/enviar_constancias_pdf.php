<?php

$folio = $_POST['folio'];
//$codigo = $_POST['codigo'];

echo $folio;

?>