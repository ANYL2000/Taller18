<?php
require_once '../assets/conexion/servidor.php';

$tallerista_seleccionado = $_GET['tallerista'];
 $taller_seleccionado = $_GET["taller"];
 $calendario_seleccionado = $_GET['calendario'];
 $turno_seleccionado = $_GET['turno'];
$dia_seleccionado = $_GET['dia'];

date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');


if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 
}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 

}else if($mes>12||$mes<1){

  echo "<script>alert('Configure correctamente su zona horaria');</script>";
  echo "<script>window.location='taller1.1.php';</script>";
}

if($calendario_seleccionado!=$año){
  echo "<script>window.location='taller1.1.php';</script>";
}

//print_r($taller_seleccionado);
$con = connect($host, $port, $db_name, $db_username, $db_password);
$conexion = mysqli_connect($host, $db_username, $db_password,$db_name );
//$query =$conexion->prepare("SELECT * FROM usuarios_talleres WHERE Ingreso = '$calendario_seleccionado' AND NombreTaller = '$taller_seleccionado' AND Dia = '$dia_seleccionado' AND Turno = '$turno_seleccionado';");
$conexion->query("SET NAMES 'utf8'");
$con->query("SET NAMES 'utf8'");
$validar_talleres = "SELECT * FROM mostrar_talleres WHERE Calendario = '$calendario_seleccionado' AND 
NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
Dia = '$dia_seleccionado'";

$filas_talleres = mysqli_query($conexion,$validar_talleres);

if(mysqli_num_rows($filas_talleres)==0){
  echo "<script type='text/javascript'>
  window.location='taller1.1.php'
  </script>";
}

while($taller = mysqli_fetch_array($filas_talleres)){

$cantidad = $taller['Registrados'];
$constancias_generadas = $taller['Constancias_generadas'];
$Fecha_inicio = $taller['Fecha_inicio'];
$Fecha_final = $taller['Fecha_final'];
}




$validar_constancias_generadas = "SELECT * FROM constancias_alumnos WHERE Ingreso = '$calendario_seleccionado' AND 
NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
Dia = '$dia_seleccionado'";

$filas_constancias_generadas = mysqli_query($conexion,$validar_constancias_generadas);


$sql = "SELECT * FROM usuarios_talleres WHERE NombreTallerista = '$tallerista_seleccionado' AND NombreTaller = '$taller_seleccionado' AND Ingreso = '$calendario_seleccionado' AND Turno = '$turno_seleccionado' AND Dia = '$dia_seleccionado';";

$result = mysqli_query($conexion,$sql);

/*$Fecha_I = new DateTime($Fecha_inicio);
$Fecha_F = new DateTime($Fecha_final);
$Fecha_I->format('d/m/Y');
$Fecha_F->format('d/m/Y');*/
//$query->execute();
//$resultado =$query->fetchAll();

//echo "<script> console.log('$taller_seleccionado') </script>";

?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<header>
    <title>Talleres</title>
</header>




<link rel="stylesheet" href="../assets/css/estilo_taller1.2.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<?php include 'header_taller.php'; ?>
</head>
<body>
    


<div class="fondo">



<a class="btn btn-primary talleres" id="talleres" href="taller1.1.php">Ir a Talleres registrados</a>

<div class="btnconstancia" id="btnconstanciaid" style="">
<p>Registrados: <?php echo $cantidad; ?> </p>
<p id="contador"></p>
<?php //if(mysqli_num_rows($filas_talleres)==0){  ?>
<button class='btn btn-success boton_constancia' id="boton_constancia" data-toggle='modal' data-target="#generarModal">Constancias</button>

</div>

<h1 class="titulo_taller">Alumnos registrados</h1>
<div class="taller_informacion">
<p id="subtitulo"> TALLERISTA: <p><?php echo "$tallerista_seleccionado"?></p> </p>
<p id="subtitulo">  TALLER: <p><?php echo "$taller_seleccionado"?></p> </p>
<p id="subtitulo">  CALENDARIO: <p> <?php echo "$calendario_seleccionado"?></p></p>
<p id="subtitulo">  TURNO: <p> <?php echo "$turno_seleccionado "?></p></p>
<p id="subtitulo">  DIA: <p> <?php echo " $dia_seleccionado" ?></p></p>
</div>

<?php if($constancias_generadas=="Si"){  ?>
<a class="btn btn-secondary constancias" id="constancias" href="constancias.php?tallerista=<?php echo $tallerista_seleccionado?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>&fecha_inicio=<?php echo $Fecha_inicio ?>&fecha_final=<?php echo $Fecha_final?>">Ver constancias</a>
<?php  } ?>


<table class="table-responsive">
    <thead>
<tr class="fila_principal">
<th scope="col">
   
   <input type="checkbox" name="todos" id="all" style="margin-left: 15px;">
 
 </th>
    <td>Codigo</td>
    <td>Nombre Completo</td>
    <td>Correo</td>
    <td>Carrera</td>
    <td>Calendario</td>
    <td>NombreTaller</td>
    <td>Dia</td>
    <td>Turno</td>
</tr>
</thead>

<tbody>


<?php  
while($fila = mysqli_fetch_array($result)){ 

?>

<tr class="filas_secundarias" id="color_filas" >
<th scope="row">
   
   <input type="checkbox" name="individual" id="individual" value="<?php echo $fila["idUsuarios"]; ?>" style="margin-left: 15px;">
  
 </th>
    <td><?php echo $fila['Codigo']; ?></td>
    <td><?php echo $fila['Nombre']; ?></td>
    <td><?php echo $fila['Correo']; ?></td>
    <td><?php echo $fila['Carrera']; ?></td>
    <td><?php echo $fila['Ingreso']; ?></td>
    <td><?php echo $fila['NombreTaller']; ?></td>
    <td><?php echo $fila['Turno']; ?></td>
    <td><?php echo $fila['Dia']; ?></td>
  <td><button type='submit' class='boton_editar' id='abrir_editar' name='abrir_editar' data-toggle='modal' data-target="#editModal<?php echo $fila['idUsuarios']; ?>">Editar</button></td>
<td><button type='submit' class='boton_borrar' data-toggle='modal' data-target="#deleteModal<?php echo $fila['idUsuarios']; ?>">Eliminar</button></td>
</tr>

</tbody>
<!--Seccion del modal de la informacion de la persona-->

<!-- Modal Editar-->
<div class="modal fade" id="editModal<?php echo $fila['idUsuarios']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar información</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
        <!--<div class="form-group">
            <label for="recipient-name" class="col-form-label">Codigo:</label>
          
            <input type="text" class="form-control" id="recipient_codigo" name="recipient_codigo" value="<?php //echo $fila["Codigo"]; ?>" required autocomplete="off">
          </div>   data-dismiss="modal"-->
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nombre Completo:</label>
            <input type="text" class="form-control" id="recipient_id" name="recipient_id" value="<?php echo $fila["idUsuarios"]; ?>" hidden="true" autocomplete="off">
            <input type="text" class="form-control" id="recipient_codigo" name="recipient_codigo" value="<?php echo $fila["Codigo"]; ?>" hidden="true" autocomplete="off">
            <input type="text" class="form-control" id="recipient_nombre"  name = "recipient_nombre" value="<?php echo $fila["Nombre"]; ?>" required autocomplete="off">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Correo Electrónico:</label>
            <input type="text" class="form-control" id="recipient_correo" name="recipient_correo" value="<?php echo $fila["Correo"]; ?>" required autocomplete="off">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Carrera:</label>
            <input type="text" class="form-control" id="recipient_carrera" name="recipient_carrera" value="<?php echo $fila["Carrera"]; ?>" required autocomplete="off">
          </div>

          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary"  >Cerrar</button>
        <button type="submit" class="btn btn-primary" id="btneditar" name="btneditar">Guardar cambios</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>

<!--Seccion del modal de la informacion de la persona-->

<!-- Modal Borrar-->
<div class="modal fade" id="deleteModal<?php echo $fila['idUsuarios'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Desea eliminar a: </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="borrar_usuario.php?id=<?php echo $fila['idUsuarios'] ?>&tallerista=<?php echo $fila['NombreTallerista'] ?>&taller=<?php echo $fila['NombreTaller'] ?>&calendario=<?php echo $fila['Ingreso'] ?>&turno=<?php echo $fila['Turno'] ?>&dia=<?php echo $fila['Dia'] ?>" method="POST">
        <div class="form-group">
            <label for="recipient-name" class="col-form-label"><?php echo $fila["Nombre"]; ?></label>
      
          </div>
       
          <div class="modal-footer">
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-danger" id="eliminar" name="eliminar">Eliminar</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>


<!--Seccion del modal de la informacion de la persona-->

<!-- Modal generar-->
<div class="modal fade" id="generarModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">¿Desea generar las constancias?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="" method="POST">
          <div class="modal-footer">
        <button type="button" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="button" class="btn btn-success" id="btngenerar" name="btngenerar" data-toggle='modal' data-target="#constanciaModal" data-dismiss="modal">Generar Constancias</button>
      </div>
      </form>
      </div>
      
    </div>
  </div>
</div>

<!--Seccion del modal de la informacion de las constancias-->

<!-- Modal informacion Constancia-->
<div class="modal fade" id="constanciaModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Datos para las constancias</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
        <!--<div class="form-group">
            <label for="recipient-name" class="col-form-label">Codigo:</label>  hidden="true"
          
            <input type="text" class="form-control" id="recipient_codigo" name="recipient_codigo" value="<?php //echo $fila["Codigo"]; ?>" required autocomplete="off">
          </div>   data-dismiss="modal"-->
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Fecha de inicio:</label>
            <?php  if($Fecha_inicio=='0000-00-00'&&$constancias_generadas=="No"){ ?>
            <input type="date" class="form-control" id="recipient_inicio"  name = "recipient_inicio" value="" required autocomplete="off">
          <?php }else{ ?>
            <input type="date" class="form-control" id="recipient_inicio"  name = "recipient_inicio" value="<?php echo date('Y-m-d', strtotime($Fecha_inicio))?>" disabled required autocomplete="off">
         <?php } ?>
          </div>

          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Fecha de finalización:</label>
            <?php  if($Fecha_final=='0000-00-00'&&$constancias_generadas=="No"){ ?>
            <input type="date" class="form-control" id="recipient_final" name="recipient_final" value="" required autocomplete="off">
            <?php }else{ ?>
              <input type="date" class="form-control" id="recipient_final" name="recipient_final" value="<?php echo date('Y-m-d', strtotime($Fecha_final))?>" disabled required autocomplete="off">
              <?php } ?>
          </div>

          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary" data-dismiss="modal" >Cerrar</button>
       <button type="submit" class="btn btn-primary" id="btninfo" name="btninfo">Ver las Constancias</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>


<?php



}
?>


</table>

<a href="lista_pdf.php?tallerista=<?php echo $tallerista_seleccionado ?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>"><button class="btn_imprimir"><i class="fa fa-print fa-2x fa-lg" ></i><p>Imprimir lista</p></button></a>

   
<?php
if(isset($_POST['btneditar'])){

    $id = $_POST['recipient_id'];
    $cod = $_POST['recipient_codigo'];
    $nombrenuevo = $_POST['recipient_nombre'];
    $carreranuevo = $_POST['recipient_carrera'];
    $correonuevo = $_POST['recipient_correo'];


    $conexion->query("UPDATE constancias_alumnos SET Nombre = '$nombrenuevo',Correo='$correonuevo',Carrera= '$carreranuevo' WHERE Codigo= '$cod' AND NombreTallerista = '$tallerista_seleccionado' AND 
    NombreTaller = '$taller_seleccionado' AND Ingreso = '$calendario_seleccionado'  AND Turno= '$turno_seleccionado' AND 
    Dia = '$dia_seleccionado'");

    $conexion->query("UPDATE usuarios_talleres SET Nombre = '$nombrenuevo',Correo='$correonuevo',Carrera= '$carreranuevo' WHERE idUsuarios= $id AND NombreTallerista = '$tallerista_seleccionado' AND 
    NombreTaller = '$taller_seleccionado' AND Ingreso = '$calendario_seleccionado'  AND Turno= '$turno_seleccionado' AND 
    Dia = '$dia_seleccionado'");



if($conexion){
    echo "<script type='text/javascript'>
    window.location='taller1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&turno=$turno_seleccionado&dia=$dia_seleccionado'
    </script>";
}else{
    echo '<script>alertaeNoti("No se pudo actualizar la informacion")</script>';
}
    
   
         
        }

?>

<?php if(isset($_POST['btninfo'])){ 
  $fecha_i = $_POST['recipient_inicio'];
  $fecha_f = $_POST['recipient_final'];

  ?>
  <script type='text/javascript'>
    window.location='constancias.php?tallerista=<?php echo $tallerista_seleccionado?>&taller=<?php echo $taller_seleccionado?>&calendario=<?php echo $calendario_seleccionado?>&turno=<?php echo $turno_seleccionado?>&dia=<?php echo $dia_seleccionado?>&fecha_inicio=<?php echo $fecha_i ?>&fecha_final=<?php echo $fecha_f?>'
    </script>
<?php } ?>

</div>
<script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>

<!--<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>-->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<script src="../assets/js/checkboxes.js"></script>



</body>
</html>
<?php  $conexion=null; ?>